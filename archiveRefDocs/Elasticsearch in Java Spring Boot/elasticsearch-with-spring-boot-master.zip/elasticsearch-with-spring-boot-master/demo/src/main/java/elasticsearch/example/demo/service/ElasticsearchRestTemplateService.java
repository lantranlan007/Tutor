package elasticsearch.example.demo.service;

public interface ElasticsearchRestTemplateService {

}
